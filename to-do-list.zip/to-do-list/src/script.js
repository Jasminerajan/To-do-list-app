function addTask() {
  const input = document.getElementById("taskInput");
  const taskText = input.value.trim();
  if (taskText === "") return;

  const li = document.createElement("li");

  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";

  const span = document.createElement("span");
  span.innerText = taskText;

  const dateSpan = document.createElement("span");
  dateSpan.className = "time";
  const now = new Date();
  dateSpan.innerText = `${now.toLocaleDateString()} ${now.toLocaleTimeString()}`;

  const editBtn = document.createElement("button");
  editBtn.innerText = "Edit";
  editBtn.className = "edit";
  editBtn.onclick = () => {
    const newTask = prompt("Edit task:", span.innerText);
    if (newTask !== null && newTask.trim() !== "") {
      span.innerText = newTask.trim();
    }
  };

  const delBtn = document.createElement("button");
  delBtn.innerText = "Delete";
  delBtn.className = "delete";
  delBtn.onclick = () => li.remove();

  li.appendChild(checkbox);
  li.appendChild(span);
  li.appendChild(dateSpan);
  li.appendChild(editBtn);
  li.appendChild(delBtn);

  document.getElementById("taskList").appendChild(li);
  input.value = "";
}
